const { db } = require('../config/database')
const bcrypt = require('bcrypt')
const mongoose = require('mongoose')
const User = require('../models/users')

const handleErrors = (err) => {
    console.log(err.message, err.code);
    let errors = { name: '', email: '', password: '', username: '' };

    //duplicate error code
    if (err.code === 11000) {
        if (err.message.includes('email')) {
            errors.email = 'that email is already registered';
        }
        else if (err.message.includes('username')) {
            errors.username = 'that ussername is already registered';
        }
        return errors;
    }

    //validation errors
    if (err.message.includes('Users validation failed:')) {
        Object.values(err.errors).forEach(({ properties }) => {
            errors[properties.path] = properties.message;
        });
    }
    return errors;
}
const getHomepage = (req, res) => {
    res.render('index.ejs');
}

const loginPage = (req, res) => {
    res.render('login.ejs');
}

const signUpPage = (req, res) => {
    res.send('hello');
}

const signUpRequest = async (req, res) => {
    const { email, name, username, password } = req.body;
    try {
        const user = await User.create({ name, email, username, password });
        res.status(201).json(user);
    }
    catch (err) {
        const errors = handleErrors(err);
        res.status(400).json({ errors });
    }
}

const loginRequest = async (req, res) => {
    console.log("req body", req.body)
    res.send("login ok");
}

module.exports = {
    getHomepage, loginPage, loginRequest, signUpPage, signUpRequest
}