const express = require('express')
const router = express.Router()
const { getHomepage, loginPage, loginRequest, signUpPage, signUpRequest } = require('../controllers/homeController')

router.get('/', getHomepage)

router.get('/login', loginPage)
router.post('/login', loginRequest)
router.get('/signup', signUpPage)
router.post('/signup', signUpRequest)
module.exports = router