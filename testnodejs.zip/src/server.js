require('dotenv').config()
const express = require('express')
const path = require('path');
const configViewEngine = require('./config/viewEngine')
const webRoutes = require('./routes/web');
const jwt = require('jsonwebtoken')


const app = express()
const port = process.env.PORT || 4444;
const hostname = process.env.HOST_NAME

//config template engine
configViewEngine(app)

//middleware 
//body req receive data
app.use(express.json())
app.use(express.urlencoded({ extended: true }))


// Route
app.use('/', webRoutes)

app.listen(port, () => {

    console.log(`App listening on port ${port}`)
})