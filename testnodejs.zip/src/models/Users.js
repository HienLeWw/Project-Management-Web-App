const mongoose = require('mongoose');
const { isEmail } = require('validator');
const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'please enter an name'],
    },
    email: {
        type: String,
        required: [true, 'please enter an email'],
        unique: [true, 'this email is already existed'],
        lowercase: true,
        validate: [isEmail, 'Please enter a valid email']
    },
    username: {
        type: String,
        required: [true, 'please enter an username'],
        unique: [true, 'this username is already existed'],
        lowercase: true
    },
    password: {
        type: String,
        required: [true, 'please enter a password'],
        minLength: [6, 'Minimum password length is 6 characters']
    },
    project_ID: {
        type: [Number]
    },
});

const User = mongoose.model('Users', userSchema);
module.exports = User;